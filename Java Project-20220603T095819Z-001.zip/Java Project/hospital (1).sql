-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2020 at 07:00 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `app_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `app_date` varchar(40) NOT NULL,
  `app_time` varchar(40) NOT NULL,
  `app_status` enum('Pending','Approved','Declined','On process') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`app_id`, `doctor_id`, `patient_id`, `app_date`, `app_time`, `app_status`) VALUES
(1, 1, 3, '2020-12-26', '1', 'Approved'),
(2, 1, 3, '2020-11-20', '1', 'Approved'),
(3, 1, 4, '2020-11-24', '16', 'Approved'),
(4, 1, 8, '2020-11-27', '4', 'Approved'),
(5, 5, 8, '2020-11-27', '11', 'Approved'),
(6, 1, 8, '2020-11-27', '7', 'Approved'),
(7, 1, 9, '2020-11-27', '3', 'Approved'),
(8, 1, 10, '2020-11-27', '5', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL,
  `doctor_fName` varchar(30) NOT NULL,
  `doctor_lName` varchar(30) NOT NULL,
  `doctor_DOB` varchar(40) NOT NULL,
  `doctor_email` varchar(40) NOT NULL,
  `doctor_pNumber` varchar(20) NOT NULL,
  `speciality` enum('Internal medicine','Pediatrician','Primary care','Allergist','Psychiatrist','Oncologist','Infectious disease doctor','Neurologist','Nephrologist') NOT NULL,
  `doctor_type` enum('Resident','Specialist','Intern') NOT NULL,
  `available_Days` text NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `doctor_fName`, `doctor_lName`, `doctor_DOB`, `doctor_email`, `doctor_pNumber`, `speciality`, `doctor_type`, `available_Days`, `password`) VALUES
(1, 'Daniel', 'James', '05/10/1990', 'daniel@gmail.com', '0789808654', 'Internal medicine', 'Resident', ' 1, 2, 3, 5', '123'),
(2, 'Amen', 'Gemeda', '1990-01-24', 'amen@gmail.com', '0712345678', 'Infectious disease doctor', 'Specialist', '[2, 3, 4, 6, 7]', '123'),
(4, 'Shem', 'Muanza', '1984-03-25', 'shem@gmail.com', '0712345678', 'Pediatrician', 'Resident', '[1, 2, 4, 5, 7]', '123'),
(5, 'Samuel', 'Nyagudi', '1996-01-26', 'samuel@gmail.com', '0786564321', 'Primary care', 'Intern', '[2, 3, 4, 5, 7]', '123');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `patient_Fname` varchar(30) NOT NULL,
  `patient_Lname` varchar(30) NOT NULL,
  `patient_email` varchar(30) NOT NULL,
  `patient_DOB` varchar(40) NOT NULL,
  `patient_password` varchar(40) NOT NULL,
  `patient_pNumber` int(11) NOT NULL,
  `patient_gender` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `patient_Fname`, `patient_Lname`, `patient_email`, `patient_DOB`, `patient_password`, `patient_pNumber`, `patient_gender`) VALUES
(3, 'John', 'Doe                           ', 'johnDoe@gmail.com', '12/34/56', '123', 987654321, 'male'),
(4, 'Biruk                         ', 'Derese                        ', 'biruk@gmail.com', '2020-11-24', '345', 798786756, 'male'),
(7, 'Hawi', 'Chala', 'hawi@gmail.com', '2012-01-24', '123', 976543212, 'male'),
(8, 'Marshal              ', 'Daniel                        ', 'marshal@gmail.com', '1998-01-04', '123', 712345678, 'male'),
(9, 'Bob', 'James', 'bob@gmail.com', '1993-01-30', '456', 786543421, 'male'),
(10, 'David                         ', 'Alonso                        ', 'david@gmail.com', '1985-02-25', '123', 789877665, 'male');

-- --------------------------------------------------------

--
-- Table structure for table `pre_appointment`
--

CREATE TABLE `pre_appointment` (
  `app_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `app_date` varchar(40) NOT NULL,
  `app_time` varchar(40) NOT NULL,
  `app_status` enum('Pending','Approved','Declined','') NOT NULL DEFAULT 'Pending',
  `speciality` enum('Internal medicine','Pediatrician','Geriatrician','Primary care','Allergist','Dermatologist','Infectious disease doctor','Ophthalmologist','Obstetrician/gynecologist','Cardiologist','Endocrinologist','Nephrologist','Urologist','Pulmonologist','Otolaryngologist','Neurologist','Psychiatrist','Oncologist','Radiologist','Rheumatologist') NOT NULL DEFAULT 'Primary care'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pre_appointment`
--

INSERT INTO `pre_appointment` (`app_id`, `patient_id`, `app_date`, `app_time`, `app_status`, `speciality`) VALUES
(1, 3, '2020-10-14', '2', 'Declined', 'Primary care'),
(2, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(3, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(4, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(5, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(6, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(7, 3, '2020-11-20', '1', 'Declined', 'Internal medicine'),
(8, 3, '2020-11-23', '3', 'Declined', 'Oncologist'),
(9, 3, '2020-11-21', '1', 'Declined', 'Internal medicine'),
(10, 3, '2020-11-21', '1', 'Declined', 'Internal medicine'),
(11, 3, '2020-11-26', '17', 'Declined', 'Psychiatrist'),
(12, 3, '2020-11-19', '1', 'Declined', 'Internal medicine'),
(13, 3, '2020-11-19', '1', 'Declined', 'Internal medicine'),
(14, 3, '2020-11-25', '6', 'Declined', 'Primary care'),
(15, 4, '2020-11-24', '1', 'Declined', 'Internal medicine'),
(17, 4, '2020-11-26', '6', 'Declined', 'Nephrologist'),
(18, 8, '2020-11-27', '4', 'Declined', 'Internal medicine'),
(19, 8, '2020-11-27', '11', 'Declined', 'Primary care'),
(22, 8, '2020-11-26', '1', 'Pending', 'Oncologist');

-- --------------------------------------------------------

--
-- Table structure for table `receptionist`
--

CREATE TABLE `receptionist` (
  `rec_id` int(11) NOT NULL,
  `rec_fName` varchar(30) NOT NULL,
  `rec_lName` varchar(30) NOT NULL,
  `rec_email` varchar(60) NOT NULL,
  `rec_pNumber` int(11) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receptionist`
--

INSERT INTO `receptionist` (`rec_id`, `rec_fName`, `rec_lName`, `rec_email`, `rec_pNumber`, `password`) VALUES
(1, 'Daniel', 'James', 'daniel@knh.com', 710203040, '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `pre_appointment`
--
ALTER TABLE `pre_appointment`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `receptionist`
--
ALTER TABLE `receptionist`
  ADD PRIMARY KEY (`rec_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pre_appointment`
--
ALTER TABLE `pre_appointment`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `receptionist`
--
ALTER TABLE `receptionist`
  MODIFY `rec_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `pre_appointment`
--
ALTER TABLE `pre_appointment`
  ADD CONSTRAINT `pre_appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  ADD CONSTRAINT `pre_appointment_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
